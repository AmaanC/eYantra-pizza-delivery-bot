#ifndef TIMER_H_
#define TIMER_H_

void timer_timer4_init();
void timer_init_devices();
void timer_1s_magic();

#endif